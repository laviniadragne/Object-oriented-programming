package com.poo.lab12.entities;

public enum Gender {
	MALE, FEMALE;
}
