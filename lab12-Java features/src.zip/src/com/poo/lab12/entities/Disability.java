package com.poo.lab12.entities;

public enum Disability {
    DISABLED, HEALTHY, ANONIMOUS
}
