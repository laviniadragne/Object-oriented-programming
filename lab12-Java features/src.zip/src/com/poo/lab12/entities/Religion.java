package com.poo.lab12.entities;

public enum Religion {
    BUDDHISM, CRISTIANITY, CALVINISM, DAOISM, HINDUISM, ISLAM
}
