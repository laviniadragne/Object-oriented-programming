package com.poo.lab12.exceptions;

public class ExistsException extends Exception {
    
	private static final long serialVersionUID = -8368249553360028667L;

	public ExistsException(String message) {
		super(message);
	}

}
