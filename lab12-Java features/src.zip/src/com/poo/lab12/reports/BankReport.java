package com.poo.lab12.reports;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.poo.lab12.entities.*;

public class BankReport {

    public static int getNumberOfCustomers(Bank bank) {
        // A customer is an Employee that works for a Business (client of the bank)

       return (int) bank.getClients().stream()
               .flatMap(aa->aa.getEmployees().stream())
               .count();

    }

    public static long getNumberOfAccounts(Bank bank) {
        // Accounts of all the customers of the bank

        return  bank.getClients().stream()
                        .flatMap(aa->aa.getEmployees().stream())
                        .flatMap(bb->bb.getAccounts().stream())
                        .count();

    }

    public static SortedSet getCustomersSorted(Bank bank) {
        // Display the set of customers in alphabetical order

        SortedSet<Employee> sortedSet = new TreeSet<>(Comparator.comparing(Employee::getName));

        bank.getClients().stream()
                .map(Business::getEmployees)
                .forEach(sortedSet::addAll);

//        bank.getClients().forEach(a->sortedSet.addAll(a.getEmployees()));
        return sortedSet;

    }

    public static double getTotalSumInAccounts(Bank bank) {
        // Sum of all customers' accounts balances

        return  bank.getClients().stream()
                .flatMap(aa->aa.getEmployees().stream())
                .flatMap(bb->bb.getAccounts().stream())
                .mapToDouble(Account::getBalance)
                .sum();

    }

    public static SortedSet getAccountsSortedBySum(Bank bank) {
        // The set of all accounts, ordered by current account balance

        TreeSet<Account> accounts = new TreeSet<>(Comparator.comparing(Account::getBalance));

        accounts.addAll(bank.getClients().stream()
                .flatMap(business -> business.getEmployees().stream())
                .flatMap(employee -> employee.getAccounts().stream()).collect(Collectors.toSet()));

//        bank.getClients().forEach(a->a.getEmployees().forEach(b->accounts.addAll(b.getAccounts())));

        return accounts;

    }

    public static Map<Employee, Collection<Account>> getCustomerAccounts(Bank bank) {
        // Return a map of all the customers with their respective accounts

        Map<Employee, Collection<Account>> newMap = new HashMap<>();

        bank.getClients()
                .forEach(e->e.getEmployees()
                .forEach(a->newMap.put(a, a.getAccounts())));

        return newMap;

    }

    public static Map<String, List<Employee>> getCustomersByCity(Bank bank) {
        // Map all the customers to their respective cities

        Map<String, List<Employee>> newMap = new HashMap<>();

        List<Employee> employeeList = new LinkedList<>();


        bank.getClients().stream()
                .map(Business::getEmployees)
                .forEach(employeeList::addAll);

        Set<String> citiesSet = employeeList.stream()
                                            .map(Employee::getCity)
                                            .collect(Collectors.toSet());

        citiesSet.forEach(c->newMap.put(c, employeeList.stream()
                                            .filter(f->f.getCity().equals(c)).collect(Collectors.toList())));

        return newMap;
    }

    public static Project getProjectWorkedOnByMostCustomers(Bank bank) {

        // Lista projects, lista employes
        // Parcurg lista de proiecte, pt fiecare proiect, parcurg lista
        // de employes.

        List<Employee> employeeList = new LinkedList<>();

        bank.getClients().stream()
                .map(Business::getEmployees)
                .forEach(employeeList::addAll);

        Set<Project> projects = bank.getClients().stream()
                .flatMap(b -> b.getEmployees().stream())
                .flatMap(e -> e.getProjects().stream()).collect(Collectors.toSet());

        Map<Project, List<Employee>> newMap = new HashMap<>();
        projects.forEach(c->newMap.put(c, employeeList
                    .stream().filter(f->f.getProjects().contains(c)).collect(Collectors.toList())));


       Map<Project, Integer> finalMap = newMap.entrySet()
                                        .stream()
                                        .collect(Collectors.toMap(Map.Entry::getKey, l->l.getValue().size()));

        return finalMap.entrySet().stream().max((entry1, entry2) -> entry1.getValue() > entry2.getValue() ? 1 : -1).get().getKey();

    }

    public static Gender getGenderWhoWorkedOnMostProjects(Bank bank) {

        List<Employee> employees = new LinkedList<>();

        bank.getClients().stream()
                        .map(Business::getEmployees)
                        .forEach(employees::addAll);

        Map<Gender, List<Employee>> employeeMap = employees.stream()
                .collect(Collectors.groupingBy(Employee::getGender));


        Map<Gender, Integer> gendreProjectsMap = employeeMap.entrySet()
                                                .stream()
                                                .collect(Collectors.toMap(Map.Entry::getKey,
                                                        list->list.getValue().stream()
                                                .mapToInt(e->e.getProjects().size())
                                                .sum()));

        if(gendreProjectsMap.get(Gender.MALE) > gendreProjectsMap.get(Gender.FEMALE)) {
            return Gender.MALE;
        } else {
            return Gender.FEMALE;
        }

    }
}
