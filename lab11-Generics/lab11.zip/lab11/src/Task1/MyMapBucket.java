package Task1;

import java.util.LinkedList;
import java.util.List;

public class MyMapBucket {
    static class MyMapEntry<K extends Comparable<K>, V> {
        private K key;
        private V value;

        MyMapEntry(K newKey, V newVal) {
            key = newKey;
            value = newVal;
        }

        K getKey() {
            return key;
        }

        V getValue() {
            return value;
        }

        void setValue(V newVal) {
            value = newVal;
        }
    }

        private List<MyMapEntry> entries;

        public MyMapBucket() {
            if (entries == null) {
                entries = new LinkedList<>();
            }
        }

        public List<MyMapEntry> getEntries() {
            return entries;
        }

        public void addEntry(MyMapEntry entry) {
            this.entries.add(entry);
        }

        public void removeEntry(MyMapEntry entry) {
            this.entries.remove(entry);
        }
}
