package Task1;

import java.util.*;
import java.util.function.Consumer;

class MyHashMap<K extends Comparable<K>, V> implements Iterable<MyMapEntry<K, V>> {

    private int CAPACITY;
    private MyMapBucket[] buckets;
    private Integer size;


    public int getCAPACITY() {
        return CAPACITY;
    }

    public void setCAPACITY(int CAPACITY) {
        this.CAPACITY = CAPACITY;
    }

    public MyMapBucket[] getBuckets() {
        return buckets;
    }

    public void setBuckets(MyMapBucket[] buckets) {
        this.buckets = buckets;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    public MyHashMap(int CAPACITY, MyMapBucket[] buckets) {
        this.CAPACITY = CAPACITY;
        this.buckets = buckets;
        this.size = 0;
    }

    private int getHash(K key) {
        return (key.hashCode() & 0xfffffff) % CAPACITY;
    }

    private MyMapBucket.MyMapEntry getEntry(K key) {
        int hash = getHash(key);
        for (int i = 0; i < buckets[hash].getEntries().size(); i++) {
            MyMapBucket.MyMapEntry myKeyValueEntry = buckets[hash].getEntries().get(i);
            if(myKeyValueEntry.getKey().equals(key)) {
                return myKeyValueEntry;
            }
        }
        return null;
    }

    public boolean containsKey(K key) {
        int hash = getHash(key);
        if (buckets != null) {
            return !(Objects.isNull(buckets[hash]) || Objects.isNull(getEntry(key)));
        }
        return false;
    }

    public void put(K key, V value) {
        if(containsKey(key)) {
            MyMapBucket.MyMapEntry entry = getEntry(key);
            entry.setValue(value);
        } else {
            int hash = getHash(key);
            if(buckets[hash] == null) {
                MyMapBucket newBucket = new MyMapBucket();
                buckets[hash] =  newBucket;
            }
            buckets[hash].addEntry(new MyMapBucket.MyMapEntry<K, V>(key, value));
            size++;
        }
    }

    public V get(K key) {
        return containsKey(key) ? (V) getEntry(key).getValue() : null;
    }

    @Override
    public Iterator<MyMapEntry<K, V>> iterator() {
        return null;
    }

    @Override
    public void forEach(Consumer<? super MyMapEntry<K, V>> action) {

    }

    @Override
    public Spliterator<MyMapEntry<K, V>> spliterator() {
        return null;
    }
}
