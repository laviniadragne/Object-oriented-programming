package Task1;

public class Main {

    public static void main(String[] args) {

        int capacity = 10;
        MyMapBucket[] buckets = new MyMapBucket[10];
        MyHashMap<MyInteger, Double> hashMap = new MyHashMap<>(capacity, buckets);

        hashMap.put(new MyInteger(0), 2.6);
        hashMap.put(new MyInteger(1), 4.5);
        hashMap.put(new MyInteger(2), 3.9);
        hashMap.put(new MyInteger(3), 1.1);
        hashMap.put(new MyInteger(4), 2.3);
        hashMap.put(new MyInteger(5), 5.3);

        Integer a = 0;

        for (int i = 0; i < hashMap.getCAPACITY(); i++) {
            if (hashMap.getBuckets()[i] != null) {
                for (int j = 0; j < (hashMap.getBuckets())[i].getEntries().size(); j++) {
                        System.out.println((hashMap.getBuckets())[i].getEntries().get(j).getKey() + " " + (hashMap.getBuckets())[i].getEntries().get(j).getValue() );
                    }
                    System.out.println();
            }
        }
    }

}

