package Task2;

public interface Sumabil {
    void addValue(Sumabil value);

}
